import 'package:flutter/cupertino.dart';

class AppViewModel extends ChangeNotifier {
  int _currentScreenIndex = 0;
  int get screenIndex => _currentScreenIndex;

  void changeScreen(index) {
    _currentScreenIndex = index;
    notifyListeners();
  }
}
