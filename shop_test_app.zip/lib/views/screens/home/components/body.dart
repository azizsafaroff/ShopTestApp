import 'package:flutter/material.dart';
import 'package:test_app/views/widgets/category_widget.dart';
import 'package:test_app/views/widgets/product_item_widget.dart';

class Body extends StatefulWidget {
  const Body({Key? key}) : super(key: key);

  @override
  State<Body> createState() => _BodyState();
}

class _BodyState extends State<Body> {
  int _collectionIndex = 0;

  @override
  Widget build(BuildContext context) {
    return NestedScrollView(
      headerSliverBuilder: (context, value) {
        return [
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 18.0),
            sliver: SliverList(
              delegate: SliverChildListDelegate(
                [
                  const SizedBox(
                    height: 20.0,
                  ),
                  const Padding(
                    padding: EdgeInsets.only(right: 80.0),
                    child: Text(
                      "You can find\nthe items you need!",
                      style: TextStyle(
                        fontSize: 24.0,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20.0,
                  ),
                  SizedBox(
                    height: 40.0,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        buildCollection(0),
                        buildCollection(1),
                        buildCollection(2),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 20.0,
                  ),
                ],
              ),
            ),
          ),
        ];
      },
      body: ListView.builder(
        itemBuilder: (context, index) => CategoryWidget(),
        itemCount: 3,
      ),
    );
  }

  Widget buildCollection(index) {
    Color color = Colors.transparent;
    Color textColor = Colors.grey;
    if (index == _collectionIndex) {
      color = Colors.orange;
      textColor = Colors.white;
    }
    return InkWell(
      onTap: () {
        _collectionIndex = index;
        setState(() {});
      },
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: 12.0,
          horizontal: 18.0,
        ),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: Text(
          'Widgets',
          style: TextStyle(
            color: textColor,
          ),
        ),
      ),
    );
  }
}
