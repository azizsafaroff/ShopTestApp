import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test_app/view_models/app_view_model.dart';
import 'package:test_app/views/screens/add/add_product_screen.dart';
import 'package:test_app/views/screens/home/home_screen.dart';
import 'package:test_app/views/screens/products/products_screen.dart';
import 'package:test_app/views/screens/profile/profile_screen.dart';
import 'package:test_app/views/widgets/bottom_navigation_bar.dart';

class AppScreen extends StatefulWidget {
  const AppScreen({Key? key}) : super(key: key);

  @override
  State<AppScreen> createState() => _AppScreenState();
}

class _AppScreenState extends State<AppScreen> {
  final List<Widget> _screens = const [
    HomeScreen(),
    AddProductScreen(),
    ProductsScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Provider(
          create: (context) => AppViewModel(),
          child: Stack(
            alignment: Alignment.center,
            children: [
              _screens[3],
              const CustomNavigationBar(),
            ],
          ),
        ),
      ),
    );
  }
}
