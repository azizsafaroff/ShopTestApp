import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test_app/view_models/app_view_model.dart';

class CustomNavigationBar extends StatelessWidget {
  const CustomNavigationBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18.0, vertical: 24.0),
        child: Container(
          height: 74.0,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(28.0),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                buildNavigationButton('Home', CupertinoIcons.home, 0, context),
                buildNavigationButton('Add', CupertinoIcons.add, 1, context),
                buildNavigationButton(
                    'Products', CupertinoIcons.square_list_fill, 2, context),
                buildNavigationButton(
                    'Profile', CupertinoIcons.person_fill, 3, context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildNavigationButton(title, icon, index, context) {
    Color _activeColor = Colors.grey;
    int currentIndex = 0;
    if (currentIndex == index) {
      _activeColor = Colors.orange;
    }
    return InkWell(
      onTap: () {
        // context.read<AppViewModel>().changeScreen(index);
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: _activeColor,
            size: 24.0,
          ),
          const SizedBox(height: 8.0),
          Text(
            title,
            style: TextStyle(
              fontSize: 14.0,
              fontWeight: FontWeight.w400,
              color: _activeColor,
            ),
          )
        ],
      ),
    );
  }
}
