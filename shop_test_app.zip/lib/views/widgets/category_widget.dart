import 'package:flutter/material.dart';

import 'product_item_widget.dart';

class CategoryWidget extends StatelessWidget {
  const CategoryWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text(
                'Popular around you',
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                'See all',
                style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w400,
                  color: Colors.orange,
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 290.0,
          child: ListView.builder(
            padding: const EdgeInsets.only(left: 18.0),
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) => ProductItemWidget(index: index),
            itemCount: 8,
          ),
        ),
      ],
    );
  }
}
